# Wishy Refactor: Decision Memo for Team Discussion

**Date:** April 12, 2026  
**Context:** Code review identified architectural issues. Two refactor approaches proposed.  
**Decision Needed:** Which path fits our situation?

---

## **The Situation**

Your codebase works but has structural issues:
- Large, tangled files (1000+ lines)
- Business rules scattered across screens and stores
- Recipient logic fragile and error-prone
- Hard to add features without breaking things
- Makes bugs harder to find and fix

**Root cause:** The app grew organically. Now it needs structure.

---

## **Two Proposals**

### **Proposal A: Full Refactor (AI Agent's Recommendation)**

**What:** Complete architectural rewrite following Domain-Driven Design (DDD)

**Scope:**
- Restructure into 5 layers: Domain → Application → Infrastructure → Presentation
- Extract all business rules into explicit services
- Rewrite repositories and persistence logic
- Create comprehensive test suite

**Timeline:** 8-12 weeks  
**Risk:** High (major changes, lots of rewriting)  
**Team Resources:** Needs focused developer, limited interruptions  
**Current Code:** Needs to be paused/frozen during refactor  
**New Features:** Blocked until refactor complete

**Benefit IF completed:**
- Cleanest architecture
- Easiest to maintain long-term
- Best foundation for scaling
- Textbook-correct design

**Risk IF goes wrong:**
- Takes 3x longer than estimated
- Bugs introduced during refactor
- Missed deadlines
- Hard to merge back if abandoned mid-way

---

### **Proposal B: Incremental Refactor (My Recommendation)**

**What:** Add structure gradually while keeping the app functional

**Phase 1 (Week 1):** Define canonical domain types
- Just create clear definitions of Wish, Connection, etc.
- No code changes — just documentation
- Takes: 20-30 hours
- Risk: Zero (no behavior changes)

**Phase 2 (Week 2-3):** Extract critical use cases
- Move key business logic into clear, reusable functions
- Update screens to call these functions
- Takes: 40-60 hours
- Risk: Low (logic stays the same, just organized)

**Phase 3+ (Later):** Full restructure if needed
- Repositories, sync layer, complete DDD
- Only if Phase 1-2 prove the approach works

**Timeline:** Start now, finish Phase 2 in 3 weeks, Phase 3 optional  
**Risk:** Low (can pause/rollback anytime)  
**Team Resources:** Can work alongside other dev work  
**Current Code:** Ships features as usual, improves incrementally  
**New Features:** Can be added during refactor  

**Benefit:**
- Immediate improvements (clearer code)
- Can pause anytime without loss
- Lets you test if this architecture works before full commitment
- New features still ship

**Risk IF goes wrong:**
- Phase 1-2 done, but helps even if you stop there
- Low downside — you only lose 3 weeks of effort

---

## **Decision Matrix**

| Question | Favors A | Favors B |
|----------|----------|----------|
| Do you have 8-12 weeks to pause other work? | ✅ YES | ❌ NO |
| Can you freeze new feature development? | ✅ YES | ❌ NO |
| Do you have test infrastructure/expertise? | ✅ YES | ❌ NO |
| Do you need to ship features in next 4 weeks? | ❌ NO | ✅ YES |
| Is this your first major refactor? | ❌ NO | ✅ YES |
| Do you want to validate the approach first? | ❌ NO | ✅ YES |
| Is architectural perfection critical? | ✅ YES | ❌ NO |

---

## **What Your Advisor Should Ask**

### **About your situation:**
1. What's the current bug/crash rate? (Is it urgent or manageable?)
2. How many new features are planned in next 3 months?
3. Do you have a dedicated developer or shared resources?
4. Is this code going to be handed off to another team, or will you maintain it?

### **About timeline:**
5. Can you commit someone full-time for 8-12 weeks? (For Proposal A)
6. Or do you prefer incremental improvements? (For Proposal B)

### **About success criteria:**
7. What would "refactor done" look like? (Fixed bugs? Better maintainability? Specific features?)
8. If the refactor takes 2x longer, would that break your roadmap?

---

## **My Assessment**

**If you're a bootstrapped founder or early-stage:**
→ **Option B** (incremental). Get structure without betting the farm.

**If you're well-funded, have dedicated eng team, no feature deadline:**
→ **Option A** (full refactor). Do it right from the start.

**If you're mid-scale, shipping features, but suffering bugs:**
→ **Option B** (incremental). Quick wins first, better decisions later.

---

## **What To Do Next**

1. **Share this memo with your advisor/team**
2. **Discuss which approach fits your constraints**
3. **Pick one approach and come back to me**
4. **I'll create a detailed week-by-week plan for whichever you choose**

---

## **Timeline For Decision**

- **This week:** Decision conversation
- **Next week:** Start whichever approach you choose
- **Week 3:** First measurable improvements

No decision needed today — but deciding by end of week keeps momentum.

---

**Questions before you present to your team?** I can answer anything to help the conversation go smoothly.
